import React from 'react'

const WasBuilt = () => {
  return (
    <div>
      wasbuilt
    </div>
  )
}

export default WasBuilt
