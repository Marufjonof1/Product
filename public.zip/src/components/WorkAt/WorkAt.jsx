import React from 'react'

const WorkAt = () => {
  return (
    <div className='Workat'>
      <div className="text">
        
      </div>
    </div>
  )
}

export default WorkAt
