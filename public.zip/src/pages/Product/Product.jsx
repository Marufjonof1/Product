import React from 'react'
import WorkAt from '../../components/WorkAt/WorkAt'
import WasBuilt from '../../components/WasBuilt/WasBuilt'

const Product = () => {
  return (
    <div className='Product'>
      <div className="Container">
        <WorkAt />
      </div>
    </div>
  )
}

export default Product
