import React from 'react'

const Resources = () => {
  return (
    <div>
      resources
    </div>
  )
}

export default Resources
